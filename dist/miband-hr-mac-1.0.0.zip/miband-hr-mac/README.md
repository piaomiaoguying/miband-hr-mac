# 小米手环 5 心率监听（macOS）

本地读取小米手环“运动心率广播”，实时显示 BPM、绘制趋势、记录 CSV，并提供 OBS 浏览器源。不登录小米账号，不需要 auth key，不上传任何数据。

## 调研结论

| 项目 | 结论 |
| --- | --- |
| 上游项目 | [Tnze/miband-heart-rate](https://github.com/Tnze/miband-heart-rate)，MIT，145 Stars |
| 支持系统 | Windows、macOS、Linux（Rust `bluest` / CoreBluetooth） |
| 官方产物 | 作者发布的可执行文件是 Windows 版；macOS 需要自行编译 |
| 支持手环 | 小米手环 4、5、6、7 的“运动心率广播” |
| 本机系统 | macOS 15.8.1（24H32），Apple M1，已在本机完成构建与面板验证 |
| 小米手环 5 | 支持，前提是官方 App 中有“运动心率广播”选项，并在手环上开始一项运动 |
| 网络与账号 | 全程本地 BLE，不需要登录，不需要 auth key |

心率数据来自小米厂商广播：Company ID `0x0157`，payload 第 4 个字节（偏移 `3`）。手环未进入运动模式时该字节通常为 `255` 或 `0`，不会产生有效心率。

## 目录

```
miband-hr-mac/
├── bin/miband-hr-mac        macOS arm64 可执行文件
├── src/                     完整 Rust 源码
├── web/                     仪表盘与 OBS 悬浮层页面
├── run.command              双击启动（真实手环）
├── mock.command             双击启动（模拟数据，预览面板）
├── diagnose.command         双击启动（打印 BLE 原始广播）
├── build.sh                 重新编译
├── data/                    CSV 与运行日志（首次启动自动创建）
├── docs/protocol.md         广播协议与调试笔记
└── README.md
```

## 快速开始

### 1. 手环准备

1. 打开手机上的 **小米运动健康** 或 **Zepp Life（原小米运动）**。
2. 进入 **我的 → 设备 → 小米手环 5**。
3. 找到 **运动心率广播**，打开开关；如果同一页面还有 **蓝牙广播**，一并打开。
4. 在手机 App 中把自动心率检测设为较高频率（可选，能加快数据更新）。
5. 把手环戴紧，选择一项运动并开始，例如 **自由训练** 或 **户外跑**。

> 心率广播只在运动进行中输出心率。只开广播、不开始运动时，广播仍在，但心率字节为 `255`。

### 2. 释放手环

关闭手机蓝牙，或至少退出小米运动健康 / Zepp Life。手环同一时间只服务一个连接对象；手机占用时，Mac 可能收不到广播。

### 3. 启动

双击 **`run.command`**。

- 首次运行 macOS 会请求蓝牙权限，选择 **允许**。
- 浏览器自动打开 `http://127.0.0.1:3030/`。
- 终端会显示扫描、设备与心率日志。

预期结果：

- 状态从“正在扫描”变为“实时”；
- 大号 BPM 每 1 秒左右更新；
- 下方出现红色心率曲线；
- `data/heart-rate-YYYY-MM-DD.csv` 持续写入。

停止：在终端按 `Ctrl-C`。

### 4. 没有手环时预览

双击 **`mock.command`**，使用生成的数据预览完整面板与 OBS 悬浮层，不访问蓝牙。地址为 `http://127.0.0.1:3031/`。

## 面板与输出

- 实时 BPM、本次最低 / 平均 / 最高、样本数；
- 最近 5 / 10 / 30 / 60 分钟趋势；
- 鼠标悬停或键盘方向键查看具体时刻；
- “数据表”展开最近 20 条记录；
- “导出 CSV”下载当前文件；
- 设备名称、设备 ID、RSSI、原始广播字节、CSV 路径。

CSV 字段：

```
timestamp,epoch_ms,device,device_id,rssi,bpm,source,raw_hex
```

`source` 取值：`adv`（运动心率广播）、`gatt`（标准心率服务）、`mock`（模拟数据）。

默认路径：`data/heart-rate-YYYY-MM-DD.csv`。按天自动新建文件。

## OBS 悬浮层

在 OBS 中添加 **浏览器** 源：

```
http://127.0.0.1:3030/overlay
```

建议尺寸 `600 × 220`，背景透明。页面只包含心形与 BPM，适合叠加在摄像头画面或直播场景上。

可选参数：

| 参数 | 示例 | 说明 |
| --- | --- | --- |
| `scale` | `?scale=1.5` | 整体缩放，范围 0.4–4 |
| `color` | `?color=%23ff3b5c` | 心形颜色，6 位十六进制 |
| `label=0` | `?label=0` | 隐藏 BPM 字样 |
| `heart=0` | `?heart=0` | 隐藏心形 |
| `bg=1` | `?bg=1` | 显示半透明深色底 |
| `hide-idle=1` | `?hide-idle=1` | 无有效心率时完全隐藏 |

示例：

```
http://127.0.0.1:3030/overlay?scale=1.4&color=%23e66767
```

无有效心率时显示 `--` 并降低透明度；恢复运动后自动回到实时数字。

## 命令行

`run.command` 会把参数原样传给程序。常用参数：

```bash
# 换端口
./bin/miband-hr-mac --port 3031

# 只接收名称或 ID 包含指定文本的设备
./bin/miband-hr-mac --device "Mi Smart Band 5"

# 心率字节偏移不是 3 时（先用 diagnose.command 确认）
./bin/miband-hr-mac --offset 4

# 标准心率服务回退（0x180D / 0x2A37）
./bin/miband-hr-mac --mode gatt --device "Mi Smart Band 5"

# 打印每条有效广播
./bin/miband-hr-mac --verbose

# 完整帮助
./bin/miband-hr-mac --help
```

`--mode gatt` 是回退路径：连接设备并订阅标准心率服务。小米手环 5 的运动心率广播默认走厂商广播，优先使用默认的 `adv` 模式。

## 诊断

双击 **`diagnose.command`**，终端会打印附近 BLE 设备的广播：

```
[诊断] name="Mi Smart Band 5" id=... rssi=-52dBm company=0x0157 len=... payload=[...] b0=... b1=... b2=... b3=...
```

排查顺序：

1. 手环开始运动后，是否出现 `company=0x0157` 的记录；
2. `b3` 是否为 20–250 之间的合理心率；
3. 若 `b3=255` 或 `0`，确认已开始运动、佩戴贴合；
4. 若 `b3` 明显不是心率，查看其它 `bN`，用 `--offset N` 指定正确偏移；
5. 找不到手环时，先关闭手机蓝牙，再运行 `diagnose.command all` 查看所有广播。

诊断日志保存在 `data/diagnose-YYYYMMDD-HHMMSS.log`。

## 硬件实测清单

按顺序执行，约 5 分钟：

1. 手环充电至 50% 以上，戴紧，传感器贴住皮肤。
2. 手机蓝牙关闭；确认小米运动健康 / Zepp Life 不在后台占用。
3. 手机 App 中“运动心率广播”为开启状态。
4. 手环上开始 **自由训练**（若异常，换 **户外跑** 再试）。
5. 双击 `run.command`，允许蓝牙权限。
6. 观察面板：状态是否在 5 秒内进入“实时”，BPM 是否在 10 秒内出现。
7. 记录 RSSI；正常应在 `-40 ~ -75 dBm`。低于 `-85 dBm` 时靠近 Mac。
8. 停止运动 10 秒，BPM 应变为 `--`；广播停止时显示“信号中断”，仍在广播但无心率时显示“等待心率”。重新开始运动应自动恢复。
9. 运行 2 分钟，点击“导出 CSV”，确认行数与 BPM 连续。
10. OBS 添加 `http://127.0.0.1:3030/overlay`，确认透明背景与实时刷新。

失败时：

- 一直“正在扫描”：运行 `diagnose.command`，看是否有 `company=0x0157`；
- 有广播但“等待心率”：看 `b3` 是否为 `255`，检查运动模式与佩戴；
- 数字异常：用 `diagnose.command` 对照 `bN`，调整 `--offset`；
- 权限问题：见下一节。

## 常见问题

**首次运行没有弹权限，或没有数据**

打开 **系统设置 → 隐私与安全性 → 蓝牙**，确认 **Terminal**（或你使用的终端）已允许。修改后退出终端再重新打开。`tccutil reset Bluetooth` 会重置所有应用的蓝牙权限，非必要不要使用。

**端口 3030 被占用**

换端口：

```bash
./bin/miband-hr-mac --port 3031
```

再访问 `http://127.0.0.1:3031/`。

**双击 `run.command` 没有反应，或提示没有执行权限**

在终端进入本目录，补一次权限：

```bash
chmod +x run.command mock.command diagnose.command build.sh bin/miband-hr-mac
```

如果系统提示“无法验证开发者”，右键 `run.command` 选择“打开”，或执行：

```bash
xattr -dr com.apple.quarantine .
```

**状态一直是“等待心率”**

广播已收到，但没有有效心率。确认：

- 手环已开始运动，而不是停在表盘；
- 手环戴紧，背面传感器贴合皮肤；
- 手机 App 中的“运动心率广播”已开启；
- 不是“户外跑”刚启动的预热阶段，可换“自由训练”。

**状态是“信号中断”**

6 秒内没有收到广播。常见原因：手环停止运动、手环离开范围、手机重新占用了手环、Mac 蓝牙被其他应用占用。

**诊断输出里的 b3 是 255、0 或明显不合理的值**

`255` / `0` 表示当前没有心率，不是真实 BPM，面板会显示 `--`。若 `b3` 是其他异常值，运行 `diagnose.command`，把 `payload` 与 `b0…b15` 记下来，用 `--offset` 指定心率所在字节。

**找不到标准心率服务（GATT 模式）**

小米手环 5 的运动心率广播不保证暴露标准 `0x180D` 服务。默认的 `adv` 模式不依赖该服务，应优先使用。

**终端窗口关闭后看不到日志**

日志追加在 `data/app.log`；诊断日志在 `data/diagnose-*.log`。

**换一台 Mac**

可执行文件为 Apple Silicon（arm64）构建。Intel Mac 或其他 macOS 版本请在目标机器上运行 `./build.sh` 重新编译。

## 技术说明

- 广播：Xiaomi / Huami Company ID `0x0157`；payload 第 4 字节为心率；约 1 Hz 更新。
- 无效值：`0`、`255`；有效范围按 `20–250` 处理。
- macOS 通过 CoreBluetooth 读取 `CBAdvertisementDataManufacturerDataKey`，使用 Rust `bluest`。
- 标准心率回退：服务 `0x180D`，特征 `0x2A37`，兼容标准心率带。
- 同一时间只跟踪一个目标设备；可用 `--device` 固定。
- 所有服务只监听 `127.0.0.1`，不对外网开放。
- 上游项目：Tnze/miband-heart-rate（MIT）。本目录的修改与新增代码同样以 MIT 发布，见 `LICENSE`。
- 协议与调试细节：`docs/protocol.md`。

## 开发

```bash
./build.sh          # cargo build --release，产物复制到 bin/
cargo test          # 广播解析、标准心率解析、CSV 转义等单元测试
```

前端为单个 HTML 文件，无 CDN、无外部字体、无构建步骤；修改 `web/` 后重新执行 `./build.sh` 即可（HTML 通过 `include_str!` 编译进二进制）。

## 参考

- [Tnze/miband-heart-rate](https://github.com/Tnze/miband-heart-rate)
- [小米手环 OBS 直播心率简明教程](https://www.bilibili.com/read/cv27510579/)
- [小米手环 5 无线心率广播应用](https://zhuanlan.zhihu.com/p/591331326)
- [Gadgetbridge](https://github.com/Freeyourgadget/Gadgetbridge)（Android 端小米手环协议参考）
